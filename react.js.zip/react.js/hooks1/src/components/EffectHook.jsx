import React, { useEffect, useState } from "react";

const EffectHook = () => {
  const [toggle, setToggle] = useState(false);
  // it render on state change
  useEffect(() => {
    console.log("useEffect called");
    console.log("Toggle = " + toggle);
  });

  return (
    <div>
      EffectHook
      <p>
        <button onClick={() => setToggle(!toggle)}>Toggle</button>
      </p>
      {toggle && <p>Toggle</p>}
    </div>
  );
};

export default EffectHook;
