import React from "react";
import { Counter } from "./components/Counter";
import EffectHook from "./components/EffectHook";

const App = () => {
  return (
    <div>
      <EffectHook />
    </div>
  );
};

export default App;
