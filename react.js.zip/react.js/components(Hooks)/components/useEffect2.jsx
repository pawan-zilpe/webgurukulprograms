import React, { useEffect } from 'react'

const useEffect2 = () => {
    useEffect(() => {
        const timer = setTimeout(() => {
            alert("3 seconds passed");
        }, 3000);

        return () => clearTimeout(timer);
    }, []);
  
    return <p>Wait for 3 seconds...</p> 


}

export default useEffect2