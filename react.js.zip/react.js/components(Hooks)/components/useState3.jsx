import React, { useState } from 'react'

const useState3 = () => {
    const [likes, setLikes] = useState(0);

  return (
    <div>
        <p>Likes: {likes}</p>
        <button onClick={() => setLikes(likes + 1)}>
            Likes
        </button>
    </div>
  )
}

export default useState3