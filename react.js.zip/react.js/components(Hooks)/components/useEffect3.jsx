import React, { useEffect } from 'react'

const useEffect3 = () => {
    useEffect(() => {
        console.log("Component has loaded");
    }, []); //runs only once
  return <p>check the console!</p>
}

export default useEffect3