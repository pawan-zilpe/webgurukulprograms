import React, { useState } from 'react'

const useState1 = () => {
    const [show, setShow] = useState(true);
  return (
    <div>
        {show && <p>This is visible text!</p>}
        <button onClick={() => setShow(!show)}>
            {show ? "Hide": "show"}
        </button>
    </div>
  )
}

export default useState1