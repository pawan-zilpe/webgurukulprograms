import React, { useEffect } from 'react'

const useEffect1 = () => {
        useEffect(() => {
            alert("page loaded!");
        }, []);  // run once when component loads
    
  return <p>welcome!</p>
}

export default useEffect1