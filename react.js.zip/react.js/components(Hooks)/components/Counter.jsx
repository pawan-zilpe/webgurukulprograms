import React, { useState } from 'react'

const Counter = () => {
    const [counter, setCounter] = useState(0);

    const handleIncrement = () => {
        setCounter(counter + 1);
    };
  return (
    <div className='counter'>
        Counter: {counter}
        <p>
            <button onClick={handleIncrement}>Increament</button>
            <button onClick={() => setCounter(counter - 1)}>Decreament</button>
            <button onClick={() => setCounter(0)}>Reset</button>
        </p>
    </div>
  )
}

export default Counter