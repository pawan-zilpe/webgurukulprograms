import React, { useState } from 'react'

const useState2 = () => {
    const [text, setText] = useState("click me");

  return (
    <button onClick={() => setText("You clicked")}>
        {text}
    </button>
  );
};

export default useState2;