import fun, { fun2 } from "./file1.js";

// when we import default function we write it outside curly braces

fun();
fun2();
console.log("we are in app file");
