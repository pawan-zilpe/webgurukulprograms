// primary
// only one function can be exported as default function
export default function fun() {
  console.log("function");
}

export function fun2() {
  console.log("function2");
}
