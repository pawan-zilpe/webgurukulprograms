import Datatable1 from "./program/Datatable1";
import Datatable from "./program/Datatable";

const App = () => {
  return (
    <div>
      <Datatable1 />
      <Datatable/>
    </div>
  );
};

export default App;
