import React from "react";

const About = () => {
  return <div>About page code</div>;
};

export default About;
