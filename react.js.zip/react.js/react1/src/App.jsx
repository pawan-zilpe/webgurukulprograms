import Home from "./Home";
import About from "./About";
import Home1  from "../src/310725/Home1";
const App = () => {
  return (
    <div className="app">
      This is App Code
      <Home user="Harish" user2="Alok" />
      <Home1/>
      <About />
    </div>
  );
};

export default App;
