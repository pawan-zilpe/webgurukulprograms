import React from "react";
// object destructuring
const Home = ({ user, user2 }) => {
  return (
    <div>
      <p> Welcome Home {user}</p>
      <p> Welcome Home {user2}</p>
    </div>
  );
};

export default Home;
