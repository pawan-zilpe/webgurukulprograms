import React from "react";
// object destructuring
const Home1 = ({ user, user2 }) => {
return (
    <div>
        <p> Welcome Home {user}</p>
        <p> Welcome Home {user2}</p>
        <header>
        <div class="container">
            <nav class="navbar">
                <a href="#" class="logo">
                    <i class="fas fa-code"></i>
                    WebCraft
                </a>
                <ul class="nav-links">
                    <li><a href="#">Home</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#gallery">Gallery</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <a href="#" class="btn">Get Started</a>
            </nav>
        </div>
    </header>
    </div>
);
};

export default Home1;
