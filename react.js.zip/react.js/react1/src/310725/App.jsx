import Home1 from "./Home1";

const App = () => {
return (
    <div className="app">
        This is App Code
        <Home1 user={"pawanzilpe"} />
    </div>
);
};

export default App;