import React, {useState} from 'react';

function Counter(){
    const[Counter, setCount] = useState(0);

    const increment = () => {
        setCount(Counter + 1);
    };
  return (
    <div>
      <h2>useState examples</h2>
      <h2>Counter : {Counter}</h2>
      <button onClick={increment}>Increment</button>
    </div>

  );
}

export default Counter;
