import React, { useRef, useLayoutEffect, useState } from 'react';

function MeasureBox() {
  const boxRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useLayoutEffect(() => {
    const box = boxRef.current;
    setDimensions({
      width: box.offsetWidth,
      height: box.offsetHeight,
    });
  }, []);

  return (
    <div>
      <div
        ref={boxRef}
        style={{
          width: '50%',
          height: '100px',
          backgroundColor: 'lightblue',
        }}
      >
        Measure Me!
      </div>
      <p>Width: {dimensions.width}px</p>
      <p>Height: {dimensions.height}px</p>
    </div>
  );
}

export default MeasureBox;