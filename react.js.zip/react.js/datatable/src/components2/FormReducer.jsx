import React, {useReducer} from 'react'

// step 1 : Reducer function
const reducer = (state, action) => {
    switch (action.type) {
        case "UPDATE_FIELD":
            return {
                ...state,
                [action.field]: action.value,
            };
            case "RESET":
                return{
                    name: "",
                    email: "",
                };
                default:
                    return state;
    }
}

// step 2: component
const FormReducer = () => {
    const [state, dispatch] = useReducer(reducer, { name: "", email: ""});
    const handleChange = (e) => {
        dispatch({
            type: "UPDATE_FIELD",
            field: e.target.name,
            value: e.target.value,
        });
    };
    const handleReset = () => {
        dispatch({ type: "RESET"});
    };

  return (
    <div style={{textAlign: "center", marginTop: "40px"}}>
        <h2>UserReducer Form</h2>
        <input type="text"
        name='name'
        placeholder='Enter name'
        value={state.name}
        onChange={handleChange}
        style={{padding: "10px", marginBottom: "10px"}} />
      <br />
      <input type="email"
      name='email'
      placeholder='Enter email'
      value={state.email}
      onChange={handleChange}
      style={{padding: "10px", marginBottom: "10px"}}
       />
       <br />
       <button onClick={handleReset}>Reset</button>
       <h4>Name : {state.name}</h4>
       <h4>Email : {state.email}</h4>
    </div>
  )
}

export default FormReducer;
