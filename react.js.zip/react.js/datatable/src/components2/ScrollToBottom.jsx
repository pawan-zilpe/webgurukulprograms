import React, { useEffect, useLayoutEffect, useRef } from 'react';

function ScrollToBottom() {
  const boxRef = useRef(null);

  useLayoutEffect(() => {
    // Box scroll hone se pehle hi scroll to bottom
    boxRef.current.scrollTop = boxRef.current.scrollHeight;
  }, []);

  return (
    <div
      ref={boxRef}
      style={{
        height: '200px',
        width: '300px',
        overflowY: 'auto',
        border: '2px solid black',
      }}
    >
      {[...Array(50)].map((_, i) => (
        <p key={`message-${i}`}>Message {i + 1}</p>
      ))}
    </div>
  );
}

export default ScrollToBottom;