import React, {useReducer, useState} from 'react'

// step 1 : Reducer function
const reducer = (state, action) => {
    switch (action.type) {
        case "ADD_TODO":
            return [
                ...state,
                {
                    id: Date.now(),
                    text: action.payload,
                    completed: false,
                },
            ];
            case "TOGGLE_TODO":
                return state.map((todo) => todo.id === action.payload ? {
                    ...todo, completed: !todo.completed
                } : todo);
            case "DELETE_TODO":
                return state.filter((todo) => todo.id !== action.payload );
                  default: 
                  return state;
    }
};

// step 2: component
const TodoReducer = () => {
    const [todos, dispatch] = useReducer(reducer, []);
    const [input, setInput] = useState("");

    const addTodo = () => {
        if (input.trim() !== "") {
            dispatch({type: "ADD_TODO", payload: input});
        }
    };
  return (
    <div style={{textAlign: "center", marginTop: "40px"}}>
        <h2>useReducer Todo List</h2>
      <input type="text"
      value={input}
      onChange={(e) => 
        setInput(e.target.value)}
        placeholder='Add a task'
        style={{padding: "10px", width: "60%"}}
     />
     <button onClick={addTodo} style={{marginLeft: "10px", padding: "10px"}}>
        + Add
     </button>

     <ul style={{listStyle: "none", padding: 0, marginTop: "20px"}}>
        {todos.map((todo) => (
            <li key={todo.id}
            style={{
                padding: "10px",
                textDecoration: todo.completed ? "line-through": "none",
                background: "#f5f5f5",
                marginBottom: "8px",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                width: "60%",
                margin: "auto",
                borderRadius: "8px",
            }}>
                <span onClick={() => dispatch({ type: "TOGGLE_TODO", payload : todo.id})}>
                    {todo.text}
                </span>
                <button onClick={() => dispatch({ type : "DELETE_TODO", payload: todo.id})}
                style={{marginLeft: "10px", padding: "5px 10px" }}>
                    ❌
                </button>
            </li>
        ))}
     </ul>
    </div>
  );
};

export default TodoReducer;
