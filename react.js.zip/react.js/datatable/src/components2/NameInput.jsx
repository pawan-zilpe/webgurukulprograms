import React, {useState} from 'react';

function NameInput() {
    const[name, setName] = useState('');  //initially empty

    const handleChange = (e) => {
        setName(e.target.value);  //input ka value update hora hai
    };
  return (
    <div>
      <input type="text"
      placeholder='Enter your name'
      value={name}
      onChange={handleChange}
       />
       <p>Hello, {name}!</p>
    </div>
  )
}

export default NameInput;
