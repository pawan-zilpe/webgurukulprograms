import React, {useState} from 'react'

function ToggleText() {
    const [Visible, setVisible] = useState(true);

    const toggle = () => {
        setVisible(!Visible);
    }
  return (
    <div>
      <button onClick={toggle}>Toggle Text</button>
      {Visible && <p>This text can be hidden or shown!</p>}
    </div>
  );
}

export default ToggleText;
