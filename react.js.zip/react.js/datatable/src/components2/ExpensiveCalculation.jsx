import React, { useMemo, useState } from "react";

const ExpensiveCalculation = () => {
  const [number, setNumber] = useState(0);
  const [dark, setDark] = useState(false);

  // 🧠 Expensive calculation
  const slowFunction = (num) => {
    console.log("⏳ Calculating slowly...");
    for (let i = 0; i < 1000000000; i++) {} // delay
    return num * 2;
  };

  // ✅ useMemo se optimized version
  const doubleNumber = useMemo(() => {
    return slowFunction(number);
  }, [number]); // number change hone par hi recalculate hoga

  const themeStyle = {
    backgroundColor: dark ? "#333" : "#fff",
    color: dark ? "#fff" : "#000",
    padding: "20px",
    textAlign: "center",
    borderRadius: "10px",
    transition: "all 0.3s ease",
  };

  return (
    <div style={themeStyle}>
      <h2>🧮 useMemo Expensive Calculation</h2>

      <input
        type="number"
        value={number}
        onChange={(e) => setNumber(parseInt(e.target.value))}
        style={{ padding: "10px", fontSize: "16px" }}
      />

      <div style={{ marginTop: "20px", fontSize: "20px" }}>
        Result: {doubleNumber}
      </div>

      <button
        onClick={() => setDark((prev) => !prev)}
        style={{ marginTop: "20px", padding: "10px 20px" }}
      >
        Toggle Theme
      </button>
    </div>
  );
};

export default ExpensiveCalculation;