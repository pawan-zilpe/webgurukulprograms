import React, {useState, useEffect} from 'react'

const Timer = () => {
    const[seconds, setSeconds] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setSeconds((prevSeconds) => prevSeconds + 1);
        }, 1000);   //har 1 sec me +1

        // clean-up function: jab component unmount ho, to interval band ho
        return() => clearInterval(interval);
    },[]);

  return (
    <div style={{textAlign: "center", marginTop: "50px"}}>
        <h2>Timer Example</h2>
        <p style={{fontSize: "24px"}}>Time Elapsed: {seconds} seconds</p>
      
    </div>
  )
}

export default Timer;
