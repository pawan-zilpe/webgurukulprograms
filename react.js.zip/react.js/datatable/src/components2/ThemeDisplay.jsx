import React, { useContext } from 'react'
import { ThemeContext } from './ThemeProvider'


const ThemeDisplay = () => {
    const {theme} = useContext(ThemeContext);

    const style = {
        backgroundColor: theme === "light" ? "#f9f9f9" : "#333",
        color : theme === "light" ? "#000" : "#fff",
        padding: "20px",
        textAlign: "center",
        minHeight: "100vh",
    };
  return (
    <div style={style}>
      <h2>Current Theme : {theme}</h2>
    </div>
  )
}

export default ThemeDisplay;
