import React, {useContext} from 'react';
import { ThemeContext } from './ThemeProvider';

const AppContent = () => {
    const {theme} = useContext(ThemeContext);

  return (
    <div style={{backgroundColor: theme === "light" ? "#fff" : "#222",
        color: theme === "light" ? "#000" : "#fff",
        minHeight: "200px",
        padding: "20px",
        textAlign: "center",
    }}>
        <p>This is the main content area with {theme} theme.</p>
      
    </div>
  )
}

export default AppContent;
