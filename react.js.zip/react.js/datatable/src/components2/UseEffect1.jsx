import React, {useState, useEffect} from 'react'

const UseEffect1 = () => {
    const[count, setCount] = useState(0);

    useEffect(() => {
        console.log('Component rendered or updated');
        document.title = `Count : ${count}`;
    }, [count]);

  return (
    <div>
      <h2>useEffect examples</h2>
<p>You click {count} times</p>
<button onClick={() => setCount(count - 1)}>Click me</button>
    </div>
  )
}

export default UseEffect1;
