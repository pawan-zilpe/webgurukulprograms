import React, { useRef, useState } from 'react';

function CountRef() {
  const count = useRef(0);
  const [renderCount, setRenderCount] = useState(0);

  const handleClick = () => {
    count.current += 1;
    alert(`Clicked ${count.current} times`);
  };

  return (
    <div>
      <h2>Click Counter (no re-render)</h2>
      <button onClick={handleClick}>Click Me</button>
      <button onClick={() => setRenderCount(prev => prev + 1)}>Re-render</button>
      <p>Re-renders: {renderCount}</p>
    </div>
  );
}

export default CountRef;