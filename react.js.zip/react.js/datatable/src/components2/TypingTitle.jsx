import React, {useState, useEffect} from 'react';
import "./TypingTitle.css";

function TypingTitle() {
    const[name, setName] = useState("");

    // useEffect to update document title
useEffect(() => {
    document.title = name? `Welcome ${name}!` : "React App";
}, [name]);  //run this effect every time name changes

  return (
    <div className='title-container'>
        <h2>What's your name?</h2>
        <input type="text"
        placeholder='Type your name'
        value={name}
        onChange={(e) => setName(e.target.value)}
        className='name-input' />
      
    </div>
  )
}

export default TypingTitle;
