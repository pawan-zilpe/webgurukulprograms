import React, {useRef, useEffect} from 'react'

function FocusInput() {
    const inputRef = useRef(null);
    useEffect(() => {
        inputRef.current.focus();  //page load hote hi input box focus hoga

    }, []);
  return (
    <div>
      <h2>Focus Input on Load</h2>
      <input type="text"
      ref={inputRef}
      placeholder='Type here...' />
    </div>
  )
}

export default FocusInput
