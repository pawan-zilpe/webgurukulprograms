import React, {useContext} from 'react'
import { ThemeContext } from './ThemeProvider'


const Header = () => {
    const{theme, toggleTheme} = useContext(ThemeContext);

  return (
    <header style={{backgroundColor: theme === "light" ? "#eee" : "#333", color: theme === "light" ? "#000" : "#fff", padding: "20px", textAlign: "center",}}>
        <h1>Theme Switcher</h1>
        <button onClick={toggleTheme}>Switch to {theme === "light" ? "Dark" : "Light"} Mode</button>
    </header>
    
  )
}

export default Header;
