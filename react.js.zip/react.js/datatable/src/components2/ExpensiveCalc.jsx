import React, { useState, useMemo } from "react";

const ExpensiveCalc = () => {
  const [number, setNumber] = useState(1);
  const [darkMode, setDarkMode] = useState(false);

  // 🔁 Expensive factorial calculation
  const factorial = useMemo(() => {
    console.log("🧠 Calculating factorial...");
    let result = 1;
    for (let i = 1; i <= number; i++) {
      for (let j = 0; j < 100000000; j++) {} // Heavy loop
      result *= i;
    }
    return result;
  }, [number]); // ⛔ Only recalculate if number changes

  const themeStyles = {
    backgroundColor: darkMode ? "#333" : "#fff",
    color: darkMode ? "#fff" : "#000",
    padding: "20px",
    textAlign: "center",
    minHeight: "100vh"
  };

  return (
    <div style={themeStyles}>
      <h2>⚙ useMemo: Expensive Calculation</h2>

      <div>
        <label>Enter Number: </label>
        <input
          type="number"
          value={number}
          onChange={(e) => setNumber(parseInt(e.target.value))}
        />
      </div>

      <div style={{ margin: "20px" }}>
        <button onClick={() => setDarkMode((prev) => !prev)}>
          Toggle Theme
        </button>
      </div>

      <h3>Factorial of {number} is: {factorial}</h3>
    </div>
  );
};

export default ExpensiveCalc;