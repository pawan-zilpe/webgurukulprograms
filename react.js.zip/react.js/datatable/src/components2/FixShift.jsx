import React, { useRef, useLayoutEffect, useState } from 'react';

function FixShift() {
  const textRef = useRef(null);
  const [text, setText] = useState("Short");

  useLayoutEffect(() => {
    const el = textRef.current;
    el.style.color = el.offsetWidth > 200 ? 'red' : 'green';
  }, [text]);

  return (
    <div>
      <h2 ref={textRef}>{text}</h2>
      <button onClick={() => setText("This is a very very long text!")}>
        Change Text
      </button>
    </div>
  );
}

export default FixShift;