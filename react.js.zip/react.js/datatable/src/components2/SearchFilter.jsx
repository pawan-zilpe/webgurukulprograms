import React, {useState, useMemo} from 'react';

const namesList = [
    "Vaishnavi",
    "Rohit",
    "Sakshi",
    "Ajay",
    "Anjali",
    "Pooja",
    "Nikhil",
    "Shruti",
    "Vikram",
    "Neha"
];

const SearchFilter = () => {
    const[searchTerm, setSearchTerm] = useState("");

    // useMemo: filtered list only updates when searchTerm changes
    const filteredNames = useMemo(() => {
        console.log("Filtering names...");
        return namesList.filter((name) => name.toLowerCase().includes(searchTerm.toLowerCase()));
    }, [searchTerm]);

  return (
    <div style={{ textAlign: "center", marginTop: "50px"}}>
        <h2>useMemo Search Filter</h2>
      <input type="text"
      placeholder='Search name...'
      value={searchTerm}
      onChange={(e) =>
        setSearchTerm(e.target.value)}
        style={{padding: "10px",
            fontSize: "16px"}} 
            />
            <ul style={{listStyle: 'none',
                padding: 0, marginTop: "20px"}}>
{filteredNames.map((name, index) => (
    <li key={index} style={{fontSize: "18px", padding: "4px 0"}}>
        {name}
    </li>
))}
            </ul>
    </div>
  )
}

export default SearchFilter
