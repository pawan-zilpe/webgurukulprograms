import React, { useRef, useEffect, useState } from 'react';

function TimerRef() {
  const intervalRef = useRef();
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    intervalRef.current = setInterval(() => {
      setSeconds(prev => prev + 1);
    }, 1000);

    return () => clearInterval(intervalRef.current); // cleanup
  }, []);

  return (
    <div>
      <h2>Timer: {seconds}s</h2>
      <button onClick={() => clearInterval(intervalRef.current)}>Stop</button>
    </div>
  );
}

export default TimerRef;