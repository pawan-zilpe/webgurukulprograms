import React, { useState } from "react";
import { userdata } from "../data";
import './Datatable.css'

const Datatable = () => {
  const [data, setData] = useState(userdata);
  const [search, setSearch] = useState("");
  // pagination: javascript
  const handleSearch = () => {
    let res = userdata.filter((item) => {
      if (
        item.first_name.toLowerCase().includes(search.toLowerCase()) ||
        item.last_name.toLowerCase().includes(search.toLowerCase()) ||
        item.gender.toLowerCase().includes(search.toLowerCase()) ||
        item.email.toLowerCase().includes(search.toLowerCase())
      ) {
        return true;
      }
      return false;
    });
    setData(res);
  };

  return (
    <div>
      <h2 align="center">Datatable</h2>
      <p align="center">
        Search :{" "}
        <input type="text" onChange={(e) => setSearch(e.target.value)} />
        <button onClick={handleSearch}>Search</button>
      </p>
      <table
        border="2"
        cellPadding={5}
        cellSpacing={5}
        rules="all"
        align="center"
      >
        <thead>
          <tr>
            <th>Id</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Gender</th>
            <th>Ip Addresss</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <tr key={index}>
                <td>{item.id}</td>
                <td>{item.first_name}</td>
                <td>{item.last_name}</td>
                <td>{item.email}</td>
                <td>{item.gender}</td>
                <td>{item.ip_address}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default Datatable;
