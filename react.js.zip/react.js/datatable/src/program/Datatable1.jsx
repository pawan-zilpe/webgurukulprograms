import React, { useState, useEffect } from "react";

const Datatable = () => {
  // Mock data similar to your userdata structure
  const userdata = [
    { id: 1, first_name: "John", last_name: "Doe", email: "john.doe@example.com", gender: "Male", ip_address: "192.168.1.1" },
    { id: 2, first_name: "Jane", last_name: "Smith", email: "jane.smith@example.com", gender: "Female", ip_address: "192.168.1.2" },
    { id: 3, first_name: "Robert", last_name: "Johnson", email: "robert.j@example.com", gender: "Male", ip_address: "192.168.1.3" },
    { id: 4, first_name: "Emily", last_name: "Williams", email: "emily.w@example.com", gender: "Female", ip_address: "192.168.1.4" },
    { id: 5, first_name: "Michael", last_name: "Brown", email: "michael.b@example.com", gender: "Male", ip_address: "192.168.1.5" },
    { id: 6, first_name: "Sarah", last_name: "Davis", email: "sarah.d@example.com", gender: "Female", ip_address: "192.168.1.6" },
    { id: 7, first_name: "David", last_name: "Miller", email: "david.m@example.com", gender: "Male", ip_address: "192.168.1.7" },
    { id: 8, first_name: "Lisa", last_name: "Wilson", email: "lisa.w@example.com", gender: "Female", ip_address: "192.168.1.8" },
    { id: 9, first_name: "James", last_name: "Moore", email: "james.m@example.com", gender: "Male", ip_address: "192.168.1.9" },
    { id: 10, first_name: "Jennifer", last_name: "Taylor", email: "jennifer.t@example.com", gender: "Female", ip_address: "192.168.1.10" },
  ];

  const [data, setData] = useState(userdata);
  const [search, setSearch] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);

  // Handle search
  useEffect(() => {
    if (search === "") {
      setData(userdata);
      return;
    }

    const filteredData = userdata.filter((item) => {
      const searchLower = search.toLowerCase();
      return (
        item.first_name.toLowerCase().includes(searchLower) ||
        item.last_name.toLowerCase().includes(searchLower) ||
        item.gender.toLowerCase().includes(searchLower) ||
        item.email.toLowerCase().includes(searchLower)
      );
    });
    setData(filteredData);
    setCurrentPage(1);
  }, [search]);

  // Handle sorting
  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
  };

  // Apply sorting
  const sortedData = React.useMemo(() => {
    let sortableItems = [...data];
    if (sortConfig.key) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [data, sortConfig]);

  // Pagination
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = sortedData.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(sortedData.length / itemsPerPage);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // Render page numbers
  const renderPageNumbers = () => {
    const pageNumbers = [];
    for (let i = 1; i <= totalPages; i++) {
      pageNumbers.push(
        <button
          key={i}
          onClick={() => paginate(i)}
          className={`px-3 py-1 rounded ${currentPage === i ? 'bg-indigo-600 text-white' : 'bg-gray-200 hover:bg-gray-300'}`}
        >
          {i}
        </button>
      );
    }
    return pageNumbers;
  };

  // Sort indicator
  const getSortIndicator = (columnName) => {
    if (sortConfig.key === columnName) {
      return sortConfig.direction === 'ascending' ? '↑' : '↓';
    }
    return null;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight mb-2">
            Modern Datatable
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            A sleek, responsive datatable with search, sorting, and pagination
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden transition-all duration-300 hover:shadow-2xl">
          <div className="p-6 border-b border-gray-100">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <h2 className="text-xl font-semibold text-gray-800">User Records</h2>
              <div className="relative w-full md:w-auto">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search records..."
                  className="w-full px-4 py-2.5 pr-10 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
                />
                <svg 
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" 
                  fill="none" 
                  stroke="currentColor" 
                  viewBox="0 0 24 24" 
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50">
                  <th 
                    className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => requestSort('id')}
                  >
                    <div className="flex items-center">
                      ID {getSortIndicator('id')}
                    </div>
                  </th>
                  <th 
                    className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => requestSort('first_name')}
                  >
                    <div className="flex items-center">
                      First Name {getSortIndicator('first_name')}
                    </div>
                  </th>
                  <th 
                    className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => requestSort('last_name')}
                  >
                    <div className="flex items-center">
                      Last Name {getSortIndicator('last_name')}
                    </div>
                  </th>
                  <th 
                    className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => requestSort('email')}
                  >
                    <div className="flex items-center">
                      Email {getSortIndicator('email')}
                    </div>
                  </th>
                  <th 
                    className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors"
                    onClick={() => requestSort('gender')}
                  >
                    <div className="flex items-center">
                      Gender {getSortIndicator('gender')}
                    </div>
                  </th>
                  <th className="px-6 py-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    IP Address
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {currentItems.map((item) => (
                  <tr 
                    key={item.id} 
                    className="hover:bg-gray-50 transition-colors duration-150"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 font-medium">{item.first_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{item.last_name}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-indigo-600">{item.email}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${
                        item.gender === 'Male' 
                          ? 'bg-blue-100 text-blue-800' 
                          : 'bg-pink-100 text-pink-800'
                      }`}>
                        {item.gender}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.ip_address}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {sortedData.length === 0 && (
            <div className="py-12 text-center">
              <svg 
                className="mx-auto h-12 w-12 text-gray-400" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" 
                />
              </svg>
              <h3 className="mt-2 text-lg font-medium text-gray-900">No records found</h3>
              <p className="mt-1 text-gray-500">Try adjusting your search query</p>
            </div>
          )}

          <div className="px-6 py-4 border-t border-gray-100 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-sm text-gray-700">
              Showing <span className="font-medium">{indexOfFirstItem + 1}</span> to{" "}
              <span className="font-medium">
                {Math.min(indexOfLastItem, sortedData.length)}
              </span>{" "}
              of <span className="font-medium">{sortedData.length}</span> results
            </div>
            
            {totalPages > 1 && (
              <div className="flex space-x-2">
                <button
                  onClick={() => currentPage > 1 && paginate(currentPage - 1)}
                  disabled={currentPage === 1}
                  className={`px-3 py-1 rounded ${currentPage === 1 ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-200 hover:bg-gray-300'}`}
                >
                  &larr; Prev
                </button>
                
                <div className="flex space-x-1">
                  {renderPageNumbers()}
                </div>
                
                <button
                  onClick={() => currentPage < totalPages && paginate(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className={`px-3 py-1 rounded ${currentPage === totalPages ? 'bg-gray-100 text-gray-400 cursor-not-allowed' : 'bg-gray-200 hover:bg-gray-300'}`}
                >
                  Next &rarr;
                </button>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>Built with React • FREME CSS Style • Modern UI Design</p>
        </div>
      </div>
    </div>
  );
};

export default Datatable;