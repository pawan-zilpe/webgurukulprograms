import React, { useState } from 'react'
import { userdata } from "../Data";

const DataTable = () => {
  const [data, setData] = useState(userdata);
  // console.log(data);
  const [search, setSearch] = useState("");
  const handleSearch = () => {
    let res = userdata.filter((item) => {
      if(item.first_name.toLocaleLowerCase().includes(search.toLocaleLowerCase()) ||
          item.last_name.toLocaleLowerCase().includes(search.toLocaleLowerCase()) ||
          item.email.toLocaleLowerCase().includes(search.toLocaleLowerCase()) ||
          item.gender.toLocaleLowerCase().includes(search.toLocaleLowerCase())
      ){
        return true;
      }
      return false;
    });
    setData(res);
  };

  return (
    <div><h1 align='center'>Data Table</h1>
    <p align='center'>
      Search:{" "} 
      <input type="text" onChange={ (e) => (setSearch(e.target.value))}/>
      <button onClick={handleSearch}>Search</button>
    </p>
    <table border="2" cellSpacing={5} cellPadding={5} rules='all' align='center'>
      <thead>
        <tr>
          <th>Id</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Ip Address</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item, index) => {
          return(
            <tr key = {index}>
              <td>{item.id}</td>
              <td>{item.first_name}</td>
              <td>{item.last_name}</td>
              <td>{item.email}</td>
              <td>{item.gender}</td>
              <td>{item.ip_address}</td>
            </tr>
          )
          
        })}
      </tbody>

    </table>
    
    </div>
  )
}

export default DataTable