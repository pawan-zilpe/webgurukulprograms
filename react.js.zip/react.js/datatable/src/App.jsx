// import Datatable from "./program/Datatable";
import Components2  from "./components2/AppContent";
import Components  from "./components";


const App = () => {
  return (
    <div>
      {/* <Datatable/> */}
      <Components2/>
      <Components/>
    </div>
  );
};

export default App;
