import Logo from "./images/logo.png";
import RightImage from "./images/right-img.png";
import Course2 from "./images/course2.png";
import Event1 from "./images/event1.png";
import Icon1 from "./images/icon1.png";
import Icon2 from "./images/icon2.png";
import Icon3 from "./images/icon2.png";
import Icon4 from "./images/icon4.png";

const App = () => {
  return (
    <div className="site-wrap">
      <header className="header">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-2 col-lg-2 col-md-2">
              <div className="logo">
                <a href="index.html">
                  <img src={Logo} alt="logo" />
                </a>
              </div>
            </div>
            <div className="col-10 col-lg-7 col-md-6">
              <div className="header-title">
                <h2 className="nav_shadow ">
                  LATE BABASAHEB GHARFALKAR <br />
                  B.Sc. NURSING COLLEGE, JODMOHA
                </h2>
                <p>Shree Sudam Shikshan Prasarak Mandal's</p>
              </div>
            </div>
            <div className="col-12 col-lg-3 col-md-4">
              <div className="header-contact">
                <p className="mb-2">
                  <a href="#">
                    <span className="me-2"> 9604111286</span>
                    <i className="fa-solid fa-phone"></i>
                  </a>
                </p>
                <p className="mb-2">
                  <a href="#">
                    <span className="me-2">lbgbncj@gmail.com</span>
                    <i className="fa-solid fa-envelope"></i>
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="menustrip">
          <div className="container">
            <div className="row">
              <div className="col-lg-2 col-md-2"></div>
              <div className="col-lg-10 col-md-10">
                <div className="mynav">
                  <div className="toggle-nav mobile-menu">
                    <span onclick="openNav()">
                      <i className="fas fa-bars"></i>
                    </span>
                  </div>
                  <div id="mySidenav" className="nav sidenav">
                    <nav id="site-navigation" className="main-navigation">
                      <a
                        href="javascript:void(0)"
                        className="closebtn mobile-menu"
                        onclick="closeNav()"
                      >
                        <i className="fa-regular fa-circle-xmark"></i>
                      </a>
                      <ul className="navbar-nav  navbar-main">
                        <li className="nav-item ">
                          <a className="nav-link active" href="index.html">
                            Home
                          </a>
                        </li>
                        <li className="nav-item ">
                          <a className="nav-link" href="about.html">
                            About
                          </a>
                        </li>
                        <li className="nav-item ">
                          <a className="nav-link" href="history.html">
                            History
                          </a>
                        </li>
                        <li className="nav-item ">
                          <a className="nav-link" href="college.html">
                            Colleges
                          </a>
                        </li>
                        <li className="nav-item ">
                          <a className="nav-link" href="contact.html">
                            Contact Us
                          </a>
                        </li>
                      </ul>
                    </nav>
                  </div>
                </div>
                <nav className="navbar navbar-expand-lg">
                  <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNavAltMarkup"
                    aria-controls="navbarNavAltMarkup"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <span className="navbar-toggler-icon"></span>
                  </button>
                  <div
                    className="collapse navbar-collapse"
                    id="navbarNavAltMarkup"
                  >
                    <ul className="navbar-nav  navbar-main">
                      <li className="nav-item ">
                        <a className="nav-link active" href="index.html">
                          Home
                        </a>
                      </li>
                      <li className="nav-item ">
                        <a className="nav-link" href="about.html">
                          About
                        </a>
                      </li>
                      <li className="nav-item ">
                        <a className="nav-link" href="history.html">
                          History
                        </a>
                      </li>
                      <li className="nav-item ">
                        <a className="nav-link" href="college.html">
                          Colleges
                        </a>
                      </li>
                      <li className="nav-item ">
                        <a className="nav-link" href="contact.html">
                          Contact Us
                        </a>
                      </li>
                    </ul>
                  </div>
                </nav>
              </div>
            </div>
          </div>
        </div>
      </header>
      <section className="homebanner py-5">
        <div className="container-fluid">
          <div className="row align-items-center">
            <div className="col-md-6 text-center">
              <p className="org-name">Shree Sudam Shikshan Prasarak Mandal's</p>
              <h1>
                late babasaheb gharfalkar
                <br /> B.Sc. nursing college, jodmoha
              </h1>
              <p className="address">Tahsil Kalamb, Dist. Yavatmal-445002</p>
              <div className="footer-line">
                <span className="president text-white">
                  <strong>Mr. Krushna D. Kadu</strong>
                  <br />
                  President
                </span>
              </div>
            </div>
            <div className="col-md-6">
              <div className="image">
                <img
                  className="img-fluid rounded-4"
                  src={RightImage}
                  alt="right img"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="about-sec">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="main-heading mb-4">
                <span>About Us</span>
              </h2>
            </div>
            <div className="col-md-6" data-aos="fade-left">
              <div className="rightimg">
                <img
                  className="img-fluid rounded-4"
                  src={Course2}
                  alt="about"
                />
              </div>
            </div>
            <div className="col-lg-6 col-md-12 mb-3" data-aos="fade-right">
              <div className="about-data">
                <div className="para">
                  <p>
                    Late Babasaheb Gharfalkar B.Sc. Nursing College, Jodmoha is
                    run by Shree Sudam Shikshan Prasarak Mandal and is committed
                    to providing high-quality education and training in the
                    field of nursing. Located in Tahsil Kalamb, Dist. Yavatmal
                    (Maharashtra), the college strives to produce skilled and
                    compassionate nursing professionals who are ready to serve
                    society with dedication and care.
                  </p>
                  <p>
                    {" "}
                    Our mission is to create a learning environment that fosters
                    academic excellence, professional integrity, and a sense of
                    social responsibility. We focus not only on theoretical
                    knowledge but also on practical clinical experience to
                    ensure our students are well-equipped for real-world
                    challenges in the healthcare industry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="cources-sec py-5" data-aos="fade-up">
        <div className="container">
          <div className="row">
            <div className="col-md-9">
              <h2 className="main-heading">
                <span>Courses</span>
              </h2>
              <p className="para">
                Our B.Sc. Nursing program is designed to provide comprehensive
                education and hands-on clinical experience that prepares
                students to become skilled, compassionate, and dedicated nursing
                professionals. The course focuses on both theoretical knowledge
                and practical applications in real healthcare settings.
              </p>
            </div>
            <div className="col-md-3">
              <div className="text-lg-end text-md-end text-center mt-lg-5 mt-md-4">
                <a href="#" type="button" className="btn-primary">
                  View All
                </a>
              </div>
            </div>
          </div>

          <div className="owl-carousel owl theme" id="hostel">
            <div className="item">
              <div className="card">
                <img src={Event1} alt="B.Sc. Nursing First Year" />
                <div className="card-body">
                  <h5 className="card-title">
                    <a href="#">B.Sc. Nursing First Year</a>
                  </h5>
                  <div className="location">
                    <img src="images/location.png" alt="location" />
                    <span>Foundation of Nursing</span>
                  </div>
                  <p className="card-text">
                    Covers basic anatomy, physiology, microbiology, psychology,
                    and nursing fundamentals. Prepares students for clinical
                    skills and patient care basics.
                  </p>
                  <a href="#" className="btn btn-link">
                    Read More
                  </a>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="card">
                <img src="images/event2.png" alt="B.Sc. Nursing Second Year" />
                <div className="card-body">
                  <h5 className="card-title">
                    <a href="#">B.Sc. Nursing Second Year</a>
                  </h5>
                  <div className="location">
                    <img src="images/location.png" alt="location" />
                    <span>Medical-Surgical Nursing I</span>
                  </div>
                  <p className="card-text">
                    Focus on adult health nursing, pharmacology, pathology, and
                    communication skills. Students begin clinical postings in
                    hospitals.
                  </p>
                  <a href="#" className="btn btn-link">
                    Read More
                  </a>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="card">
                <img src="images/event3.png" alt="B.Sc. Nursing Third Year" />
                <div className="card-body">
                  <h5 className="card-title">
                    <a href="#">B.Sc. Nursing Third Year</a>
                  </h5>
                  <div className="location">
                    <img src="images/location.png" alt="location" />
                    <span>Pediatric & Psychiatric Nursing</span>
                  </div>
                  <p className="card-text">
                    Studies focus on child health, mental health nursing,
                    community health, and research. Includes field training and
                    seminars.
                  </p>
                  <a href="#" className="btn btn-link">
                    Read More
                  </a>
                </div>
              </div>
            </div>

            <div className="item">
              <div className="card">
                <img src="images/event1.png" alt="B.Sc. Nursing Final Year" />
                <div className="card-body">
                  <h5 className="card-title">
                    <a href="#">B.Sc. Nursing Final Year</a>
                  </h5>
                  <div className="location">
                    <img src="images/location.png" alt="location" />
                    <span>Leadership & Midwifery</span>
                  </div>
                  <p className="card-text">
                    Focus on midwifery, nursing management, professional trends,
                    and ethics. Final-year internships are conducted in reputed
                    hospitals.
                  </p>
                  <a href="#" className="btn btn-link">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="home-vmsec">
        <div className="container">
          <div className="row">
            <div className="col-12 col-md-6">
              <div className="card">
                <h2 className="text-center marginBottom">Our Vision</h2>
                <p className="text-center">
                  "To be a leader amongst B.Sc. Nursing College in
                  India,persistently pursuing excellence,and offering world
                  class education with morals."
                </p>
              </div>
            </div>
            <div className="col-12 col-md-6">
              <div className="card">
                <h2 className="text-center marginBottom">Our Mission</h2>
                <p className="text-center">
                  "To educate rural population and to make them competent and
                  skilled in the field of pharmacy to fulfill global
                  requirements by providing quality education and opportunities
                  to young aspirants, who will serve the nation’s ‘Health Care’
                  in an excellent Manner."
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="contact-sec">
        <div className="container">
          <div className="row">
            <div className="col-md-12">
              <h2 className="main-heading">
                <span>Contact Us</span>
              </h2>
            </div>

            <div className="col-lg-4 col-md-6 mb-3" data-aos="fade-right">
              <div className="location-box">
                <h5>Location</h5>
                <p className="para">
                  If you have any queries regarding admissions, course
                  structure, or campus facilities, feel free to reach out to us
                  or visit our campus.
                </p>
                <ul className="contact-list list-group list-group-flush">
                  <li className="list-group-item">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0">
                        <img src={Icon1} alt="icon1" />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>Head Office</h6>
                        <p className="address">
                          Late Babasaheb Gharfalkar B.Sc. Nursing College,
                          Jodmoha, Tahsil Kalamb, Dist. Yavatmal – 445002,
                          Maharashtra
                        </p>
                      </div>
                    </div>
                  </li>

                  <li className="list-group-item">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0">
                        <img src={Icon2} alt="icon2" />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>Call Us</h6>
                        <p>
                          <a href="tel:+919988776655">+91 99887 76655</a>
                        </p>
                      </div>
                    </div>
                  </li>

                  <li className="list-group-item">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0">
                        <img src={Icon3} alt="icon3" />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>Email</h6>
                        <p>
                          <a href="mailto:lbgbncj@gmail.com">
                            lbgbncj@gmail.com
                          </a>
                        </p>
                      </div>
                    </div>
                  </li>

                  <li className="list-group-item">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0">
                        <img src={Icon4} alt="icon4" />
                      </div>
                      <div className="flex-grow-1 ms-3">
                        <h6>Website</h6>
                        <p>
                          <a href="http://www.lbgbncj.org" target="_blank">
                            www.lbgbncj.org
                          </a>
                        </p>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>

            <div className="col-lg-4 col-md-6 mb-3" data-aos="fade-up">
              <div className="location-box">
                <h5>Send a Message</h5>
                <p className="para">
                  Interested in joining our B.Sc. Nursing program? Fill out the
                  form below and we will get back to you shortly.
                </p>
                <div className="contact-info">
                  <form>
                    <div className="mb-3">
                      <input
                        type="text"
                        className="form-control"
                        id="name"
                        placeholder="Name*"
                      />
                    </div>
                    <div className="mb-3">
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        placeholder="Email*"
                      />
                    </div>
                    <div className="mb-3">
                      <input
                        type="number"
                        className="form-control"
                        id="number"
                        placeholder="Phone Number*"
                      />
                    </div>
                    <div className="mb-3">
                      <textarea
                        className="form-control"
                        id="message"
                        placeholder="Your Message*"
                      ></textarea>
                    </div>
                    <button
                      type="submit"
                      className="btn btn-primary w-100 rounded"
                    >
                      Send
                    </button>
                  </form>
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-md-12 mb-3" data-aos="fade-left">
              <div className="google-map">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3764.445946320719!2d78.22190067504456!3d19.34639164317959!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd3f2e07c34b3f9%3A0x885f2433fdc801fc!2sJodmoha%2C%20Maharashtra%20445002!5e0!3m2!1sen!2sin!4v1720423844313!5m2!1sen!2sin"
                  width="100%"
                  height="400"
                  style={{ border: "0" }}
                  allowfullscreen=""
                  loading="lazy"
                ></iframe>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer className="site-footer border-top pt-5" data-aos="fade-up">
        <div className="container">
          <div className="row">
            <div className="col-lg-4 col-md-12 mb-3">
              <div className="footer-box">
                <div className="flogo mb-3" data-aos="fade-right">
                  <a href="index.html">
                    <img src={Logo} alt="logo" />
                  </a>
                </div>
                <div className="footer-line">
                  <span className="president">
                    <strong>Mr. Krushna D. Kadu</strong>
                    <br />
                    President
                  </span>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-md-6">
              <h5 className="footer-heading mb-4">Address</h5>
              <p>Shree Sudam Shikshan Prasarak Mandal's</p>
              <h6 className="small-heading nav_shadow mb-4">
                LATE BABASAHEB GHARFALKAR <br />
                B.Sc. NURSING COLLEGE, JODMOHA
              </h6>
              <p className="address">Tahsil Kalamb, Dist. Yavatmal-445002</p>
            </div>
            <div className="col-lg-4 col-md-6">
              <h5 className="footer-heading mb-4">Get in touch</h5>
              <ul className="list-unstyled">
                <li>
                  <a href="tel:9988776655">+91 9988776655 </a>
                </li>
                <li>
                  <a href="mailTo:lbgbncj@gmail.com">lbgbncj@gmail.com</a>
                </li>
              </ul>
              <div className="newsletter-footer">
                <form>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="example@example.com"
                  />
                  <button
                    className="btn-primary rounded py-2"
                    type="button"
                    id="button-addon2"
                  >
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div className="footer-copy">
          <div className="container">
            <div className="row">
              <div className="col-md-6">
                <p className="mb-0">© Copyright 2025 All Rights Reserved </p>
              </div>
              <div className="col-md-6 text-lg-end">
                <p className="mb-0">
                  Design and Developed by: Ambe Technologies
                </p>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
