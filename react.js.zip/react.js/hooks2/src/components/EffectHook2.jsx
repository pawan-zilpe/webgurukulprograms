import React, { useEffect, useState } from "react";

const EffectHook = () => {
  // variable
  const [toggle, setToggle] = useState(false);
  const [data1, setData1] = useState("username");
  const [data2, setData2] = useState("username2");
  const [data3, setData3] = useState("age");
  // it render on state change
  useEffect(() => {console.log("useEffect called");}, [data1,data2,data3]);

  return (
    <>
    <div>
      EffectHook
      <p>
        <button onClick={() => setToggle(!toggle)}>Toggle</button>
      </p>
      {toggle && <p>Toggle</p>}
      {data1}
      <button
        onClick={() => {
          setData1("button clicked");
        }}
      >
        Click
      </button>
    </div>


    

    <div>
      EffectHook
      <p>
        <button onClick={() => setToggle(!toggle)}>Toggle</button>
      </p>
      {toggle && <p>Toggle</p>}
      {data2}
      <button
        onClick={() => {
          setData2("button clicked");
        }}
      >
        Click
      </button>
    </div>

    <div>
      EffectHook
      <p>
        <button onClick={() => setToggle(!toggle)}>Toggle</button>
      </p>
      {toggle && <p>Toggle</p>}
      {data3}
      <button
        onClick={() => {
          setData3("button clicked");
        }}
      >
        Click
      </button>
    </div>
    </>
  );
};

export default EffectHook;
