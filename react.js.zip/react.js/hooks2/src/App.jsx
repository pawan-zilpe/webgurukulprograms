import React from "react";

// import  Counter1  from "./components/Counter1";
// import  Counter2  from "./components/Counter2";
// import  Counter3  from "./components/Counter3";


import EffectHook1 from "./components/EffectHook1";
import EffectHook2 from "./components/EffectHook2";
import EffectHook3 from "./components/EffectHook3";



import UseRefHook1 from "./components/UseRefHook1";
import UseRefHook2 from "./components/UseRefHook2";
import UseRefHook3 from "./components/UseRefHook3";



import UseLayoutEffect1 from "./components/UseLayoutEffect1";
import UseLayoutEffect2 from "./components/UseLayoutEffect2";
import UseLayoutEffect3 from "./components/UseLayoutEffect3";

const App = () => {
  return (
    <div>
      {/* <React/> */}

      {/* <Counter1/>
      <Counter2/>
      <Counter3/> */}

      <UseLayoutEffect1/>
      <UseLayoutEffect2/>
      <UseLayoutEffect3/>

      <UseRefHook1/>
      <UseRefHook2/>
      <UseRefHook3/>

      <EffectHook1/>
      <EffectHook2/>
      <EffectHook3/>
      
      
    </div>
  );
};

export default App;
